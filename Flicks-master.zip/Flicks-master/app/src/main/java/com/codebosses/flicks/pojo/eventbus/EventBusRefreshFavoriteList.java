package com.codebosses.flicks.pojo.eventbus;

public class EventBusRefreshFavoriteList {
}
